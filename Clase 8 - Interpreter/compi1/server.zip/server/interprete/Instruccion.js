class Instruccion {
    constructor(){}

    interpretar(entorno){}

    getArbol(){}
}

module.exports = Instruccion;